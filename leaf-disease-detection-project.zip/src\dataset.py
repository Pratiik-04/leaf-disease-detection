from pathlib import Path

import tensorflow as tf

from src.config import BATCH_SIZE, IMAGE_SIZE, RANDOM_SEED


def load_training_and_validation_data(
    data_dir: Path,
    validation_split: float = 0.2,
    batch_size: int = BATCH_SIZE,
) -> tuple[tf.data.Dataset, tf.data.Dataset, list[str]]:
    if not data_dir.exists():
        raise FileNotFoundError(f"Training dataset folder not found: {data_dir}")

    train_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        validation_split=validation_split,
        subset="training",
        seed=RANDOM_SEED,
        image_size=IMAGE_SIZE,
        batch_size=batch_size,
        label_mode="categorical",
    )

    validation_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        validation_split=validation_split,
        subset="validation",
        seed=RANDOM_SEED,
        image_size=IMAGE_SIZE,
        batch_size=batch_size,
        label_mode="categorical",
    )

    class_names = train_ds.class_names
    return optimize_dataset(train_ds), optimize_dataset(validation_ds), class_names


def load_labeled_test_data(
    data_dir: Path,
    batch_size: int = BATCH_SIZE,
) -> tuple[tf.data.Dataset, list[str]]:
    if not data_dir.exists():
        raise FileNotFoundError(f"Test dataset folder not found: {data_dir}")

    test_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        shuffle=False,
        image_size=IMAGE_SIZE,
        batch_size=batch_size,
        label_mode="categorical",
    )

    class_names = test_ds.class_names
    return optimize_dataset(test_ds), class_names


def optimize_dataset(dataset: tf.data.Dataset) -> tf.data.Dataset:
    return dataset.cache().prefetch(buffer_size=tf.data.AUTOTUNE)

