import json
from pathlib import Path


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def save_class_names(class_names: list[str], output_path: Path) -> None:
    ensure_dir(output_path.parent)
    with output_path.open("w", encoding="utf-8") as file:
        json.dump(class_names, file, indent=2)


def load_class_names(path: Path) -> list[str]:
    if not path.exists():
        raise FileNotFoundError(
            f"Class names file not found at {path}. Train the model first."
        )

    with path.open("r", encoding="utf-8") as file:
        class_names = json.load(file)

    if not isinstance(class_names, list) or not class_names:
        raise ValueError(f"Invalid class names file: {path}")

    return class_names

