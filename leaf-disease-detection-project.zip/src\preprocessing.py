from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

from src.config import IMAGE_SIZE, SUPPORTED_IMAGE_EXTENSIONS


def is_supported_image(path: Path) -> bool:
    return path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS


def list_images(folder: Path) -> list[Path]:
    if not folder.exists():
        raise FileNotFoundError(f"Image folder not found: {folder}")

    images = [
        path
        for path in folder.rglob("*")
        if path.is_file() and is_supported_image(path)
    ]
    return sorted(images)


def load_image_with_pil(image_path: Path, image_size: tuple[int, int] = IMAGE_SIZE) -> np.ndarray:
    with Image.open(image_path) as image:
        image = image.convert("RGB")
        image = image.resize(image_size)
        return np.asarray(image, dtype=np.float32)


def load_image_with_opencv(
    image_path: Path,
    image_size: tuple[int, int] = IMAGE_SIZE,
) -> np.ndarray:
    image = cv2.imread(str(image_path))
    if image is None:
        raise ValueError(f"Unable to read image: {image_path}")

    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = cv2.resize(image, image_size)
    return image.astype(np.float32)


def prepare_image_for_model(image_path: Path) -> np.ndarray:
    image = load_image_with_opencv(image_path)
    image = np.expand_dims(image, axis=0)
    return preprocess_input(image)

