"""Leaf disease detection package."""

